package be.vyncke;

public interface Application {}
