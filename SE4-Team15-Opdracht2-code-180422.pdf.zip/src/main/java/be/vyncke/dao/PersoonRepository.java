package be.vyncke.dao;

import be.vyncke.domain.Personeel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PersoonRepository extends JpaRepository<Personeel, Integer> {

}
