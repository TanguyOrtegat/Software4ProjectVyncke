package be.vyncke.service;

import java.util.Date;
import java.util.List;

import be.vyncke.dao.PersoonRepository;
import be.vyncke.dao.ProjectRepository;
import be.vyncke.domain.Personeel;
import be.vyncke.domain.Persoon;
import be.vyncke.domain.Project;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.*;

@Service("brainstormSessieService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly=true)
public class BrainstormSessieServiceImpl implements BrainstormSessieService {

    @Autowired
    private PersoonRepository persoonRepository = null;
    @Autowired
    private ProjectRepository projectRepository = null;

    public BrainstormSessieServiceImpl(){}

    public List<Personeel> geefAllePersoneel() {
        return persoonRepository.findAll();
    }

    public List<Project> geefAlleProjecten() {
        return projectRepository.findAll();
    }

	@Transactional(propagation= Propagation.REQUIRED,readOnly=false)
    public Personeel zoekPersoneelMetId(int id){
		return persoonRepository.findOne(id);
    }

    @Transactional(propagation= Propagation.REQUIRED,readOnly=false)
    public Project zoekProjectMetId(int id){
        return projectRepository.findOne(id);
    }

    @Override
    public void personeelToewijzen(Project project, Personeel personeel) {
        personeel.setProject(project);
        persoonRepository.save(personeel);
    }

    @Transactional(propagation= Propagation.REQUIRED,readOnly=false)
    public Personeel voegPersoneelToe(String voornaam, String familienaam, String departement, String functie) {
    	return persoonRepository.save( createPersoneel(voornaam,familienaam,functie, departement) );
    }

    private Personeel createPersoneel(String voornaam, String familienaam, String departement, String functie) {
    	return new Personeel(voornaam, familienaam, functie, departement);
	}

	public Personeel getPersoon(int id) {
        return  persoonRepository.getOne(id);
    }

    @Override
    public void pasPersoneelAan(Personeel personeel, String voornaam, String familienaam, String functie, String departement) {
        personeel.setVoornaam(voornaam);
        personeel.setFamilienaam(familienaam);
        personeel.setFunctie(functie);
        personeel.setDepartement(departement);
        persoonRepository.save(personeel);
    }

    public void deletePersoneel(int id) {
        persoonRepository.delete(id);
    }
}