package be.vyncke.service;

import be.vyncke.domain.Personeel;
import be.vyncke.domain.Persoon;
import be.vyncke.domain.Project;
import org.aspectj.runtime.internal.PerObjectMap;

import java.util.Date;
import java.util.List;

public interface BrainstormSessieService {

    public List<Personeel> geefAllePersoneel();

    public Personeel voegPersoneelToe(String voornaam, String familienaam, String departement, String functie);

    public Personeel zoekPersoneelMetId(int id);

    public void deletePersoneel(int id);

    public Personeel getPersoon(int id);

    public void pasPersoneelAan(Personeel personeel, String voornaam, String familienaam, String functie, String departement);

    public List<Project> geefAlleProjecten();

    public Project zoekProjectMetId(int id);

    public void personeelToewijzen(Project project, Personeel personeel);
}