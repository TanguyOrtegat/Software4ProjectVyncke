package be.vyncke.controller;

import be.vyncke.domain.Personeel;
import be.vyncke.domain.Persoon;
import be.vyncke.domain.Project;
import be.vyncke.service.BrainstormSessieService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/")
public class PersoonController {

    @Autowired
    protected BrainstormSessieService brainstormSessieService=null; // ready for dependency injection

    @RequestMapping(value={"/home.html","/index.html","lijst.html"},method=RequestMethod.GET)
    public String index(ModelMap model){
        List<Personeel> deLijst = brainstormSessieService.geefAllePersoneel();
        List<Project> projectLijst = brainstormSessieService.geefAlleProjecten();
        model.addAttribute("personen", deLijst);
        model.addAttribute("projecten", projectLijst);
        return "/index";
    }
    // je zal naar index.jsp gaan

    @RequestMapping(value={"/persoon.html"},method=RequestMethod.GET)
    public String persoonDetail(@RequestParam("id") Integer id, ModelMap model){
        Personeel persoon = brainstormSessieService.zoekPersoneelMetId(id);
        model.addAttribute("persoon", persoon);
        return "/persoon";
    }
    // je zal naar persoon.jsp gaan
    
    @RequestMapping(value={"/nieuwePersoon.html"},method=RequestMethod.GET)
    public String persoonFormulier(ModelMap model){
        Personeel personeel = new Personeel();
        model.addAttribute("depersoon", personeel);
        return "/nieuwePersoon";
    }
    // je zal naar nieuwePersoon.jsp gaan

    @RequestMapping(value={"/nieuwePersoon.html"},method=RequestMethod.POST)
    public String persoonToevoegen(@ModelAttribute("depersoon") Personeel personeel, ModelMap model){
        Persoon toegevoegdPersoon = brainstormSessieService.voegPersoneelToe(personeel.getVoornaam(),
                personeel.getFamilienaam(), personeel.getDepartement(), personeel.getFunctie());
        System.out.println("DEBUG persoonsgegevens familienaam: "+personeel.getFamilienaam());
        return "redirect:persoon.html?id="+toegevoegdPersoon.getId();
    }
    // je zal naar de detailpagina van de toegevoegde persoon gaan

    @RequestMapping(value = {"{delete}"}, method = RequestMethod.POST)
    public String persoonVerwijderen(@RequestParam("id") Integer id, ModelMap model) {
        brainstormSessieService.deletePersoneel(id);
        return "redirect:index.html";
    }

    @RequestMapping(value={"/personeelAanpassen.html"},method=RequestMethod.GET)
    public String persoonOmAanTePassen(@RequestParam("id") Integer id, ModelMap model){
        Personeel persoon = brainstormSessieService.zoekPersoneelMetId(id);
        model.addAttribute("depersoon", persoon);
        return "/personeelAanpassen";
    }

    @RequestMapping(value={"/personeelAanpassen.html"},method=RequestMethod.POST)
    public String persoonAanpassen(@ModelAttribute("depersoon") Personeel personeel, ModelMap model){
        brainstormSessieService.pasPersoneelAan(personeel, personeel.getVoornaam(), personeel.getFamilienaam(), personeel.getFunctie(), personeel.getDepartement());
        System.out.println("DEBUG persoonsgegevens familienaam: "+personeel.getFamilienaam());
        return "redirect:persoon.html?id="+personeel.getId();
    }
}
