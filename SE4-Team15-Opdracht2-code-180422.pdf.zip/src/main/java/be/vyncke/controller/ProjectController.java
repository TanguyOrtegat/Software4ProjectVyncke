package be.vyncke.controller;


import be.vyncke.domain.Personeel;
import be.vyncke.domain.Project;
import be.vyncke.service.BrainstormSessieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Set;

@Controller
@RequestMapping("/")
public class ProjectController {
    @Autowired
    protected BrainstormSessieService brainstormSessieService=null;

    @RequestMapping(value={"/project.html"},method= RequestMethod.GET)
    public String projectDetail(@RequestParam("id") Integer id, ModelMap model){
        Project project = brainstormSessieService.zoekProjectMetId(id);
        Set<Personeel> toegewezenPersonen = project.getPersoneel();
        model.addAttribute("project", project);
        model.addAttribute("personen", toegewezenPersonen);
        return "/project";
    }

    @RequestMapping(value={"/personeelToewijzen.html"},method= RequestMethod.GET)
    public String personeelToewijzen(@RequestParam("id") Integer id, ModelMap model){
        Project project = brainstormSessieService.zoekProjectMetId(id);
        List<Personeel> personen = brainstormSessieService.geefAllePersoneel();
        model.addAttribute("project", project);
        model.addAttribute("personen", personen);
        return "/personeelToewijzen";
    }

    @RequestMapping(value = {"{personeelToewijzen/{projectId}"}, method = RequestMethod.POST)
    public String personeelToewijzen(@RequestParam("projectId") Integer projectId, @RequestParam("personeelId") Integer personeelId, ModelMap model) {
        Personeel personeel = brainstormSessieService.zoekPersoneelMetId(personeelId);
        Project project = brainstormSessieService.zoekProjectMetId(projectId);
        brainstormSessieService.personeelToewijzen(project, personeel);
        return "redirect:project.html?id="+projectId;
    }
}
