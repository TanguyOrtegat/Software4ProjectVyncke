package be.vyncke.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
import java.util.Set;

@Entity
@Table(name="projecten")
public class Project implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int Id;

    @OneToMany(cascade = CascadeType.ALL,
            fetch = FetchType.LAZY,mappedBy = "project")
    private Set<Personeel> personeel;

    @Column
    private String status;

    @Column
    private String naam;

    @OneToOne
    @JoinColumn(name = "bestelling_id")
    private Bestelling bestelling;

    public Project(Bestelling bestelling, int id, Set<Personeel> personeel, String status, String naam) {
        this.bestelling = bestelling;
        Id = id;
        this.personeel = personeel;
        this.status = status;
        this.naam = naam;
    }

    public Project() {

    }

    public void projectAfwerken(){

    }
    public void projectOnHold(){

    }
    public void projectToewijzen(){

    }

    public Bestelling getBestelling() {
        return bestelling;
    }

    public void setBestelling(Bestelling bestelling) {
        this.bestelling = bestelling;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public Set<Personeel> getPersoneel() {
        return personeel;
    }

    public void setPersoneel(Set<Personeel> personeel) {
        this.personeel = personeel;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }
}
