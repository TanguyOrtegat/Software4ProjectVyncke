package be.vyncke.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name="bestellingen")
public class Bestelling implements Serializable {

    private static final long serialVersionUID = 1L;

    @javax.persistence.Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int Id;

    @OneToMany(mappedBy = "bestelling")
    private List<Commercieleketel> Items;

    @OneToOne
    @JoinColumn(name = "klant_id")
    private Klant klant;


    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public List<Commercieleketel> getItems() {
        return Items;
    }

    public void setItems(List<Commercieleketel> items) {
        Items = items;
    }

    public Klant getKlant() {
        return klant;
    }

    public void setKlant(Klant klant) {
        this.klant = klant;
    }

    public Bestelling(int id, List<Commercieleketel> items, Klant klant) {
        Id = id;
        Items = items;
        this.klant = klant;
    }

    public Bestelling() {

    }

    public void BestellingAfronden(){

    }
    public void BestellingGeneren(){

    }
    public void BestellingGoedkeuren(){

    }
    public void BestellingWeigeren(){

    }
    public void BestellingWijzigen(){

    }
    public void OverzichtOproepen(){

    }

}
